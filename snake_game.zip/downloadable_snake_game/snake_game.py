# snake_game.py
# HSnake — Tkinter single-file final rewrite (Skin Editor opens in a popup Toplevel)
# Requires phrases.py (a list variable named `phrases`) in same folder.

import tkinter as tk
import random
import math
import time
import sys
import os
import threading

# ---------------- CONFIG ----------------
SCREEN_WIDTH, SCREEN_HEIGHT = 900, 700
MAP_WIDTH, MAP_HEIGHT = 7000, 7000
SEG_SIZE = 20

PLAYER_BASE_SPEED = 8.0
NPC_BASE_SPEED = 7.0
MAX_SPEED_CAP = 25.0

FOOD_TARGET = 350
NPC_COUNT = 20
MINIMAP_SIZE = 160

# Food types: color, value, rarity (sum of rarities should be <=1)
FOOD_TYPES = [
    {"color":"#ff3333","value":1,"rarity":0.58},   # red common
    {"color":"#ffd24d","value":2,"rarity":0.30},   # yellow uncommon
    {"color":"#66ff66","value":5,"rarity":0.10},   # green rare
    {"color":"#00f5ff","value":10,"rarity":0.02}   # neon very rare
]

NPC_NAMES = [
    "Zyra","Kilo","Mako","Luna","Nova","Rex","Juno","Orion","Echo","Vega","Axel","Sora",
    "Lyra","Kael","Niko","Aria","Cyra","Drake","Eris","Talon","Nyx","Riven","Selin","Vior",
    "Kora","Axen","Lyric","Zane","Faye","Orin","Iris","Caius","Rhea","Jax","Liora","Veyra"
]

NPC_COLORS = ["#00ffff","#ff8c00","#8a2be2","#ff69b4","#7fff00","#ffd700","#00bfff","#87ceeb","#ffffff","#40e0d0"]

START_SIZE_WEIGHTS = [50,25,15,5,3,1,1]  # weights for sizes 1..7

# ---------------- UTILITIES ----------------
def choose_food_type():
    r = random.random()
    acc = 0.0
    for t in FOOD_TYPES:
        acc += t["rarity"]
        if r <= acc:
            return t["color"], t["value"]
    # fallback
    return FOOD_TYPES[0]["color"], FOOD_TYPES[0]["value"]

def weighted_start_size():
    choices = [1,2,3,4,5,6,7]
    return random.choices(choices, weights=START_SIZE_WEIGHTS, k=1)[0]

def clamp(v, a, b):
    return max(a, min(b, v))

def dist(a,b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

# ---------------- MAIN GAME CLASS ----------------
class SnakeGame:
    def __init__(self, root):
        self.root = root
        self.root.title("HSnake")
        self.font = ("Arial", 14)
        self.large_font = ("Arial", 28)
        self.username = ""
        self.running = False
        self.paused = False

        # load phrases safely
        try:
            import phrases
            self.phrases = getattr(phrases, "phrases", ["Play HSnake"])
            if not isinstance(self.phrases, list):
                self.phrases = ["Play HSnake"]
        except Exception:
            self.phrases = ["Play HSnake"]

        # ----- Username UI -----
        self.username_frame = tk.Frame(root, bg="black")
        tk.Label(self.username_frame, text="Enter Username:", font=self.font, fg="yellow", bg="black").pack(pady=8)
        self.username_entry = tk.Entry(self.username_frame, font=self.font)
        self.username_entry.pack(pady=4)
        tk.Button(self.username_frame, text="Continue", font=self.font, command=self.go_to_menu,
                  bg="gray20", fg="yellow").pack(pady=8)
        self.username_frame.pack(expand=True)

        # ----- Splash text canvas -----
        self.text_canvas = tk.Canvas(root, width=SCREEN_WIDTH, height=50, bg="black", highlightthickness=0)
        self.animated_text_id = None
        self.text_size = 22
        self.text_growing = True

        # ----- Menu -----
        self.menu_frame = tk.Frame(root, bg="black")
        tk.Label(self.menu_frame, text="HSnake", font=self.large_font, fg="yellow", bg="black").pack()
        self.splash_label = tk.Label(self.menu_frame, text=random.choice(self.phrases), font=self.font, fg="white", bg="black")
        self.splash_label.pack(pady=6)
        tk.Button(self.menu_frame, text="Start Game", font=self.font, command=self.start_game,
                  bg="gray20", fg="yellow").pack(pady=6)
        tk.Button(self.menu_frame, text="Skin Editor", font=self.font, command=self.open_skin_editor,
                  bg="gray20", fg="yellow").pack(pady=4)
        tk.Button(self.menu_frame, text="Quit", font=self.font, command=self.root.quit,
                  bg="gray20", fg="yellow").pack(pady=4)

        # ----- Canvas & bindings -----
        self.canvas = tk.Canvas(root, width=SCREEN_WIDTH, height=SCREEN_HEIGHT, bg="black")
        self.root.bind("<Key>", self.on_key)
        self.root.bind("<Motion>", self.on_mouse)

        # ----- Game state -----
        self.player = {"body":[], "len":0, "skin":["#79b6ff"], "username":"Player"}
        self.foods = []
        self.npcs = []
        self.camera_x = 0
        self.camera_y = 0
        self.mouse_x = SCREEN_WIDTH//2
        self.mouse_y = SCREEN_HEIGHT//2
        self.pause_frame = None
        self.speed_bonuses = []
        self.leaderbox = None

        # skins palettes
        self.skin_default_palette = ["#ff3333","#ff8c00","#ffd24d","#66ff66","#0066ff","#8a2be2","#ff69b4","#7fff00","#ffd700","#00ffff"]
        self.more_shades = ["#990000","#ff4500","#ffb84d","#33cc33","#0047b3","#5d3fd3","#ff1493","#228b22","#b8860b","#008b8b"]

        # start splash anim
        self.update_phrase()
        self.animate_text()

    # ---------- UI flows ----------
    def go_to_menu(self):
        self.username = self.username_entry.get() or "Player"
        self.player["username"] = self.username
        self.username_frame.pack_forget()
        self.show_menu()

    def show_menu(self):
        self.text_canvas.pack()
        self.menu_frame.pack(pady=10)

    def update_phrase(self):
        self.text_canvas.delete("all")
        phrase = random.choice(self.phrases)
        self.animated_text_id = self.text_canvas.create_text(SCREEN_WIDTH//2, 25, text=phrase, font=("Arial", self.text_size), fill="yellow")
        self.root.after(3000, self.update_phrase)

    def animate_text(self):
        if not self.animated_text_id:
            self.root.after(50, self.animate_text)
            return
        if self.text_growing:
            self.text_size += 1
            if self.text_size >= 36:
                self.text_growing = False
        else:
            self.text_size -= 1
            if self.text_size <= 22:
                self.text_growing = True
        self.text_canvas.itemconfig(self.animated_text_id, font=("Arial", self.text_size))
        self.root.after(50, self.animate_text)

    # ---------- Start & Reset ----------
    def start_game(self):
        self.menu_frame.pack_forget()
        self.text_canvas.pack_forget()
        self.canvas.pack()
        self.reset_game()
        self.running = True
        self.update_game()

    def reset_game(self):
        self.canvas.delete("all")
        px = random.randint(SEG_SIZE*10, MAP_WIDTH-SEG_SIZE*10)
        py = random.randint(SEG_SIZE*10, MAP_HEIGHT-SEG_SIZE*10)
        start_size = weighted_start_size()
        self.player["body"] = [(px - i*SEG_SIZE, py) for i in range(start_size)]
        self.player["len"] = len(self.player["body"])
        self.player["username"] = self.username or "Player"
        self.speed_bonuses = []
        self.foods = [self.create_food() for _ in range(FOOD_TARGET)]
        self.npcs = []
        for _ in range(NPC_COUNT):
            self.spawn_npc(center_box=True)
        self.camera_x = px - SCREEN_WIDTH//2
        self.camera_y = py - SCREEN_HEIGHT//2
        # remove any pause frame if present
        if self.pause_frame:
            try:
                self.pause_frame.destroy()
            except Exception:
                pass
            self.pause_frame = None

    def create_food(self, pos=None):
        if pos:
            c,v = choose_food_type()
            return {"pos":pos,"value":v,"color":c}
        attempts = 0
        while True:
            attempts += 1
            x = random.randint(SEG_SIZE*3, (MAP_WIDTH-SEG_SIZE*4)//SEG_SIZE)*SEG_SIZE
            y = random.randint(SEG_SIZE*3, (MAP_HEIGHT-SEG_SIZE*4)//SEG_SIZE)*SEG_SIZE
            if (x,y) not in self.player["body"] and all((x,y) not in npc["body"] for npc in self.npcs):
                c,v = choose_food_type()
                return {"pos":(x,y),"value":v,"color":c}
            if attempts > 800:
                return {"pos":(x,y),"value":1,"color":FOOD_TYPES[0]["color"]}

    def spawn_npc(self, center_box=False):
        size = weighted_start_size()
        if center_box:
            cx = MAP_WIDTH//2 + random.randint(-300,300)
            cy = MAP_HEIGHT//2 + random.randint(-300,300)
        else:
            cx = random.randint(SEG_SIZE*10, MAP_WIDTH-SEG_SIZE*10)
            cy = random.randint(SEG_SIZE*10, MAP_HEIGHT-SEG_SIZE*10)
        body = [(cx - i*SEG_SIZE, cy) for i in range(size)]
        npc = {"name":random.choice(NPC_NAMES), "body":body, "color":random.choice(NPC_COLORS), "last_dir":(1,0)}
        self.npcs.append(npc)

    # ---------- Input ----------
    def on_key(self, event):
        if event.keysym == "Escape":
            self.toggle_pause()

    def on_mouse(self, event):
        self.mouse_x = event.x
        self.mouse_y = event.y

    # ---------- Pause ----------
    def toggle_pause(self):
        self.paused = not self.paused
        if self.paused:
            if not self.pause_frame:
                self.create_pause_frame()
            self.pause_frame.lift()
        else:
            if self.pause_frame:
                try:
                    self.pause_frame.destroy()
                except Exception:
                    pass
                self.pause_frame = None
            # resume update loop
            self.root.after(50, self.update_game)

    def create_pause_frame(self):
        self.pause_frame = tk.Frame(self.canvas, bg="black")
        self.pause_frame.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(self.pause_frame, text="Paused", font=self.large_font, fg="yellow", bg="black").pack(pady=10)
        tk.Button(self.pause_frame, text="Resume", font=self.font, command=self.toggle_pause,
                  bg="gray20", fg="yellow").pack(pady=6)
        tk.Button(self.pause_frame, text="Back to Menu", font=self.font, command=self.back_to_menu,
                  bg="gray20", fg="yellow").pack(pady=6)
        tk.Button(self.pause_frame, text="Quit", font=self.font, command=self.root.quit,
                  bg="gray20", fg="yellow").pack(pady=6)
        self.pause_frame.lower()

    def back_to_menu(self):
        if self.pause_frame:
            try: self.pause_frame.destroy()
            except: pass
            self.pause_frame = None
        self.paused = False
        self.running = False
        self.canvas.pack_forget()
        self.menu_frame.pack(pady=10)
        self.text_canvas.pack()

    # ---------- Speed bonuses ----------
    def ensure_speed_bonuses(self):
        needed = (len(self.player["body"]) - 1) // 20
        while len(self.speed_bonuses) < needed:
            roll = round(random.uniform(0.5, 1.5), 3)
            self.speed_bonuses.append(roll)

    def player_speed(self):
        self.ensure_speed_bonuses()
        s = PLAYER_BASE_SPEED + sum(self.speed_bonuses)
        # cap
        return min(s, MAX_SPEED_CAP)

    # ---------- Movement & AI ----------
    def move_player(self):
        hx, hy = self.player["body"][0]
        dx = (self.mouse_x + self.camera_x) - hx
        dy = (self.mouse_y + self.camera_y) - hy
        d = math.hypot(dx,dy)
        if d == 0:
            return hx, hy
        speed = max(3.0, self.player_speed())
        nx = hx + int(dx/d * speed)
        ny = hy + int(dy/d * speed)
        nx = clamp(nx, -SEG_SIZE, MAP_WIDTH + SEG_SIZE)
        ny = clamp(ny, -SEG_SIZE, MAP_HEIGHT + SEG_SIZE)
        return nx, ny

    def npc_choose_target(self, npc):
        hx, hy = npc["body"][0]
        # food within range
        foods_in_range = [f for f in self.foods if abs(f["pos"][0]-hx)+abs(f["pos"][1]-hy) < 2500]
        if foods_in_range:
            foods_in_range.sort(key=lambda f: (-f["value"], abs(f["pos"][0]-hx)+abs(f["pos"][1]-hy)))
            return ("food", foods_in_range[0])
        # consider attacking
        candidates = []
        # player if near and similar or weaker
        ph = self.player["body"][0]
        if dist((hx,hy), ph) < 1600 and len(self.player["body"]) <= len(npc["body"]) + 6:
            candidates.append(("player", ph))
        # npc heads
        for other in self.npcs:
            if other is npc: continue
            oh = other["body"][0]
            if dist((hx,hy), oh) < 1200 and len(other["body"]) <= len(npc["body"]) + 6:
                candidates.append(("npc", oh))
        if candidates:
            candidates.sort(key=lambda t: dist((hx,hy), t[1]))
            return candidates[0]
        # wander to center
        return ("wander", (MAP_WIDTH//2 + random.randint(-400,400), MAP_HEIGHT//2 + random.randint(-400,400)))

    def npc_compute_intercept(self, npc, target_pos, target_dir, target_speed):
        hx, hy = npc["body"][0]
        dist_to_target = dist((hx,hy), target_pos)
        look_ahead = clamp(dist_to_target / 200.0, 1.0, 6.0)
        tx = target_pos[0] + target_dir[0] * target_speed * look_ahead
        ty = target_pos[1] + target_dir[1] * target_speed * look_ahead
        return (tx, ty)

    def move_npc(self, npc):
        hx, hy = npc["body"][0]
        chosen = self.npc_choose_target(npc)
        if chosen[0] == "food":
            tx, ty = chosen[1]["pos"]
        elif chosen[0] == "player":
            if len(self.player["body"]) >= 2:
                ph = self.player["body"][0]; ph_prev = self.player["body"][1]
                pdir = (ph[0]-ph_prev[0], ph[1]-ph_prev[1])
                plen = math.hypot(pdir[0], pdir[1]) or 1
                pdir = (pdir[0]/plen, pdir[1]/plen)
            else:
                pdir = (1,0)
            p_speed = self.player_speed()
            tx, ty = self.npc_compute_intercept(npc, self.player["body"][0], pdir, p_speed)
        elif chosen[0] == "npc":
            tx, ty = self.npc_compute_intercept(npc, chosen[1], (0,0), NPC_BASE_SPEED)
        else:
            tx, ty = chosen[1]

        dx, dy = tx - hx, ty - hy
        d = math.hypot(dx,dy)
        if d == 0:
            return hx, hy

        # avoidance forces
        steer_x = dx / d; steer_y = dy / d
        wall_avoid_x = 0; wall_avoid_y = 0
        margin = 120
        if hx < margin: wall_avoid_x += (margin - hx)
        if hx > MAP_WIDTH - margin: wall_avoid_x -= (hx - (MAP_WIDTH - margin))
        if hy < margin: wall_avoid_y += (margin - hy)
        if hy > MAP_HEIGHT - margin: wall_avoid_y -= (hy - (MAP_HEIGHT - margin))

        repel_x = 0; repel_y = 0
        for other in self.npcs:
            if other is npc: continue
            ohx, ohy = other["body"][0]
            dhead = dist((hx,hy),(ohx,ohy))
            if dhead < 60:
                repel_x += (hx - ohx)
                repel_y += (hy - ohy)
        # avoid player when player big
        if len(self.player["body"]) > len(npc["body"]) + 6:
            phx, phy = self.player["body"][0]
            if dist((hx,hy),(phx,phy)) < 200:
                repel_x += (hx - phx)*1.5
                repel_y += (hy - phy)*1.5

        vx = steer_x*1.0 + wall_avoid_x*0.02 + repel_x*0.02
        vy = steer_y*1.0 + wall_avoid_y*0.02 + repel_y*0.02
        vlen = math.hypot(vx, vy) or 1
        vx /= vlen; vy /= vlen

        npc_len = len(npc["body"])
        speed = max(3.0, NPC_BASE_SPEED - (npc_len//30))
        nx = hx + int(vx * speed)
        ny = hy + int(vy * speed)
        nx = clamp(nx, -SEG_SIZE, MAP_WIDTH + SEG_SIZE)
        ny = clamp(ny, -SEG_SIZE, MAP_HEIGHT + SEG_SIZE)
        npc["last_dir"] = (vx, vy)
        return nx, ny

    # ---------- eating & collisions ----------
    def player_eat(self):
        phx, phy = self.player["body"][0]
        for f in self.foods[:]:
            fx, fy = f["pos"]
            if abs(phx - fx) < SEG_SIZE and abs(phy - fy) < SEG_SIZE:
                for _ in range(f["value"]):
                    self.player["body"].append(self.player["body"][-1])
                    self.player["len"] += 1
                try:
                    self.foods.remove(f)
                except ValueError:
                    pass
                return

    def npc_eat(self, npc):
        nhx, nhy = npc["body"][0]
        for f in self.foods[:]:
            fx, fy = f["pos"]
            if abs(nhx - fx) < SEG_SIZE and abs(nhy - fy) < SEG_SIZE:
                for _ in range(f["value"]):
                    npc["body"].append(npc["body"][-1])
                try:
                    self.foods.remove(f)
                except ValueError:
                    pass
                return

    def scatter_into_food(self, segments, spread=4):
        for (sx, sy) in segments:
            rx = sx + random.randint(-spread*SEG_SIZE, spread*SEG_SIZE)
            ry = sy + random.randint(-spread*SEG_SIZE, spread*SEG_SIZE)
            rx = clamp(rx, SEG_SIZE, MAP_WIDTH-SEG_SIZE)
            ry = clamp(ry, SEG_SIZE, MAP_HEIGHT-SEG_SIZE)
            # spawn as single red pieces
            self.foods.append({"pos":(rx,ry),"value":1,"color":FOOD_TYPES[0]["color"]})

    def check_collisions_slither(self):
        # player head vs NPC body
        phx, phy = self.player["body"][0]
        for npc in self.npcs:
            for seg in npc["body"]:
                if abs(phx - seg[0]) < SEG_SIZE and abs(phy - seg[1]) < SEG_SIZE:
                    self.scatter_into_food(self.player["body"][:], spread=3)
                    self.reset_after_player_death()
                    return True

        # head-head collisions
        heads = [("player", (phx,phy), None)]
        for npc in self.npcs:
            heads.append(("npc", npc["body"][0], npc))
        for i in range(len(heads)):
            for j in range(i+1, len(heads)):
                t1, p1, o1 = heads[i]
                t2, p2, o2 = heads[j]
                if abs(p1[0]-p2[0]) < SEG_SIZE and abs(p1[1]-p2[1]) < SEG_SIZE:
                    if t1=="player" or t2=="player":
                        self.scatter_into_food(self.player["body"][:], spread=4)
                        if t1=="npc" and o1 in self.npcs:
                            self.scatter_into_food(o1["body"][:], spread=4); self.npcs.remove(o1); self.spawn_npc(center_box=True)
                        if t2=="npc" and o2 in self.npcs:
                            self.scatter_into_food(o2["body"][:], spread=4); self.npcs.remove(o2); self.spawn_npc(center_box=True)
                        self.reset_after_player_death()
                        return True
                    else:
                        if o1 in self.npcs:
                            self.scatter_into_food(o1["body"][:], spread=4); self.npcs.remove(o1); self.spawn_npc(center_box=True)
                        if o2 in self.npcs:
                            self.scatter_into_food(o2["body"][:], spread=4); self.npcs.remove(o2); self.spawn_npc(center_box=True)
                        return True

        # NPC head vs player body (excluding player head)
        for npc in self.npcs[:]:
            nhx, nhy = npc["body"][0]
            for idx, pseg in enumerate(self.player["body"][1:], start=1):
                if abs(nhx - pseg[0]) < SEG_SIZE and abs(nhy - pseg[1]) < SEG_SIZE:
                    if npc in self.npcs:
                        self.scatter_into_food(npc["body"][:], spread=3)
                        self.npcs.remove(npc); self.spawn_npc(center_box=True)
                    return True

        # NPC head vs other NPC body -> attacker dies
        for attacker in self.npcs[:]:
            ahx, ahy = attacker["body"][0]
            for victim in self.npcs[:]:
                if attacker is victim: continue
                for seg in victim["body"]:
                    if abs(ahx - seg[0]) < SEG_SIZE and abs(ahy - seg[1]) < SEG_SIZE:
                        if attacker in self.npcs:
                            self.scatter_into_food(attacker["body"][:], spread=3)
                            self.npcs.remove(attacker); self.spawn_npc(center_box=True)
                        return True
        return False

    def reset_after_player_death(self):
        self.running = False
        self.canvas.create_text(SCREEN_WIDTH//2, SCREEN_HEIGHT//2, text="You died — returning to menu...", fill="red",
                                font=self.large_font, tag="gameover")
        self.speed_bonuses = []
        self.root.after(1200, self.back_to_menu)

    # ---------- Main update ----------
    def update_game(self):
        if not self.running or self.paused:
            self.root.after(50, self.update_game)
            return

        # maintain food pool
        while len(self.foods) < FOOD_TARGET:
            self.foods.append(self.create_food())

        # move player
        new_head = self.move_player()
        self.player["body"].insert(0, new_head)
        # trim
        self.player["body"] = self.player["body"][:self.player["len"]]

        # player eat
        self.player_eat()

        # move NPCs
        for npc in self.npcs[:]:
            old = npc["body"][:]
            nh = self.move_npc(npc)
            npc["body"] = [nh] + old[:-1]
            self.npc_eat(npc)

        # collisions
        if self.check_collisions_slither():
            self.root.after(50, self.update_game)
            return

        # boundary
        phx, phy = self.player["body"][0]
        if phx < 0 or phy < 0 or phx >= MAP_WIDTH or phy >= MAP_HEIGHT:
            self.scatter_into_food(self.player["body"][:], spread=4)
            self.reset_after_player_death()
            self.root.after(50, self.update_game)
            return

        # camera smoothing
        px, py = self.player["body"][0]
        self.camera_x += int((px - self.camera_x - SCREEN_WIDTH//2) * 0.12)
        self.camera_y += int((py - self.camera_y - SCREEN_HEIGHT//2) * 0.12)

        # draw
        self.draw()

        self.root.after(50, self.update_game)

    # ---------- draw ----------
    def draw(self):
        self.canvas.delete("all")
        left = max(0, self.camera_x - SEG_SIZE*12)
        top = max(0, self.camera_y - SEG_SIZE*12)
        right = min(MAP_WIDTH, self.camera_x + SCREEN_WIDTH + SEG_SIZE*12)
        bottom = min(MAP_HEIGHT, self.camera_y + SCREEN_HEIGHT + SEG_SIZE*12)

        # grid (square)
        grid_step = SEG_SIZE * 5
        start_x = (left // grid_step) * grid_step
        start_y = (top // grid_step) * grid_step
        for gx in range(start_x, right + grid_step, grid_step):
            for gy in range(start_y, bottom + grid_step, grid_step):
                self.canvas.create_rectangle(gx - self.camera_x, gy - self.camera_y,
                                             gx + grid_step - self.camera_x, gy + grid_step - self.camera_y,
                                             outline="#333", fill="", tag="bg")

        # red boundary
        self.canvas.create_rectangle(-self.camera_x, -self.camera_y,
                                     MAP_WIDTH - self.camera_x, MAP_HEIGHT - self.camera_y,
                                     outline="red", width=4, tag="bg")

        # draw foods
        for f in self.foods:
            fx, fy = f["pos"]
            if fx < left-SEG_SIZE or fx > right+SEG_SIZE or fy < top-SEG_SIZE or fy > bottom+SEG_SIZE:
                continue
            self.canvas.create_rectangle(fx - self.camera_x, fy - self.camera_y,
                                         fx + SEG_SIZE - self.camera_x, fy + SEG_SIZE - self.camera_y,
                                         fill=f["color"], tag="food")

        # draw NPCs
        for npc in self.npcs:
            for i, (x,y) in enumerate(npc["body"]):
                if x < left-SEG_SIZE or x > right+SEG_SIZE or y < top-SEG_SIZE or y > bottom+SEG_SIZE:
                    continue
                if i == 0:
                    self.canvas.create_rectangle(x - self.camera_x, y - self.camera_y,
                                                 x + SEG_SIZE - self.camera_x, y + SEG_SIZE - self.camera_y,
                                                 fill=npc["color"], outline="black", tag="npc")
                else:
                    self.canvas.create_rectangle(x - self.camera_x, y - self.camera_y,
                                                 x + SEG_SIZE - self.camera_x, y + SEG_SIZE - self.camera_y,
                                                 fill=npc["color"], tag="npc")
            hx, hy = npc["body"][0]
            if left <= hx <= right and top <= hy <= bottom:
                self.canvas.create_text(hx - self.camera_x + SEG_SIZE//2, hy - self.camera_y - 10,
                                        text=npc["name"], fill="white", font=("Arial", 10), tag="npc")

        # draw player (thickness scales slowly)
        for i, (x,y) in enumerate(self.player["body"]):
            length = len(self.player["body"])
            extra = (length // 12) * 2
            block = SEG_SIZE + extra
            offset = (block - SEG_SIZE)//2
            color = self.player["skin"][i % len(self.player["skin"])] if self.player["skin"] else "#79b6ff"
            self.canvas.create_rectangle(x - offset - self.camera_x, y - offset - self.camera_y,
                                         x + SEG_SIZE + offset - self.camera_x, y + SEG_SIZE + offset - self.camera_y,
                                         fill=color, outline="black", tag="player")

        # player name
        phx, phy = self.player["body"][0]
        if left <= phx <= right and top <= phy <= bottom:
            self.canvas.create_text(phx - self.camera_x + SEG_SIZE//2, phy - self.camera_y - 12,
                                    text=self.player["username"], fill="white", font=self.font, tag="ui")

        # scoreboard & leaderboard
        self.draw_leaderboard()

        # minimap
        self.draw_minimap()

    def draw_leaderboard(self):
        self.canvas.delete("leader")
        entries = [("You", len(self.player["body"]))] + [(npc["name"], len(npc["body"])) for npc in self.npcs]
        entries.sort(key=lambda x: x[1], reverse=True)
        x0 = SCREEN_WIDTH - 200
        y0 = 12
        self.canvas.create_rectangle(x0 - 6, y0 - 6, SCREEN_WIDTH - 6, y0 + 20 * (min(10,len(entries)) + 1),
                                     fill="#070707", outline="#333", tag="leader")
        self.canvas.create_text(x0 + 50, y0, anchor="n", text="Leaderboard", fill="yellow", font=("Arial", 12), tag="leader")
        for i,(name,length) in enumerate(entries[:10]):
            self.canvas.create_text(x0, y0 + 20 * (i + 1), anchor="nw",
                                    text=f"{i+1}. {name}: {length}", fill="white", font=("Arial", 11), tag="leader")

    def draw_minimap(self):
        self.canvas.delete("minimap")
        ratio_x = MINIMAP_SIZE / MAP_WIDTH
        ratio_y = MINIMAP_SIZE / MAP_HEIGHT
        rx = SCREEN_WIDTH - MINIMAP_SIZE - 12
        ry = SCREEN_HEIGHT - MINIMAP_SIZE - 12
        self.canvas.create_rectangle(rx, ry, rx + MINIMAP_SIZE, ry + MINIMAP_SIZE, outline="white", tag="minimap")
        px, py = self.player["body"][0]
        self.canvas.create_rectangle(rx + int(px*ratio_x), ry + int(py*ratio_y),
                                     rx + int(px*ratio_x) + 4, ry + int(py*ratio_y) + 4, fill="green", tag="minimap")
        for npc in self.npcs:
            hx, hy = npc["body"][0]
            self.canvas.create_rectangle(rx + int(hx*ratio_x), ry + int(hy*ratio_y),
                                         rx + int(hx*ratio_x) + 4, ry + int(hy*ratio_y) + 4,
                                         fill=npc["color"], tag="minimap")

    # ---------- Skin Editor (popup Toplevel) ----------
    def open_skin_editor(self):
        win = tk.Toplevel(self.root)
        win.title("Skin Editor")
        win.configure(bg="black")
        tk.Label(win, text="Choose up to 10 colors for your snake (click to cycle):", font=self.font, fg="white", bg="black").pack(pady=6)
        grid = tk.Frame(win, bg="black")
        grid.pack()
        self.skin_buttons = []
        max_cells = 10
        working = self.player["skin"][:] if self.player["skin"] else self.skin_default_palette[:max_cells]
        while len(working) < max_cells:
            working.append("#ffffff")
        for i in range(max_cells):
            color = working[i]
            b = tk.Button(grid, bg=color, width=4, height=2, command=lambda idx=i: self.cycle_color(idx))
            b.grid(row=0, column=i, padx=3, pady=3)
            self.skin_buttons.append(b)
        def add_more():
            for i, shade in enumerate(self.more_shades):
                if i < len(self.skin_buttons):
                    self.skin_buttons[i]["bg"] = shade
        tk.Button(win, text="More colors (shades)", command=add_more, bg="gray20", fg="yellow").pack(pady=6)
        def save_and_close():
            colors = [b["bg"] for b in self.skin_buttons if b["bg"]!="#ffffff"]
            if not colors:
                colors = ["#79b6ff"]
            self.player["skin"] = colors[:10]
            win.destroy()
        tk.Button(win, text="Save Skin", command=save_and_close, bg="gray20", fg="yellow").pack(pady=6)

    def cycle_color(self, idx):
        options = self.skin_default_palette + self.more_shades + ["#ffffff"]
        current = self.skin_buttons[idx]["bg"]
        try:
            i = options.index(current)
            nxt = options[(i+1)%len(options)]
        except ValueError:
            nxt = options[0]
        self.skin_buttons[idx]["bg"] = nxt

# ---------- Run ----------
if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg="black")
    game = SnakeGame(root)
    root.mainloop()

# 🐍 HSnake

A free **Python snake.io**-style game built with **Tkinter**.  
Eat food, grow your snake, outsmart the AI, and dominate the leaderboard!  
Simple, fast, and completely offline — no installs needed beyond Python itself.

---

## 🎮 Features
- Huge 7000×7000 map with smooth camera movement  
- 4 types of food (common to legendary)  
- Smart NPC snakes that hunt, dodge, and fight  
- Dynamic leaderboard (top 10)  
- Minimap for tracking activity  
- Skin Editor with 10 colors + optional light/dark shades  
- Gradual speed increase as you grow  
- Realistic slither-style collisions  
- Pause menu, custom username, and fun splash phrases  

---

## ⚙️ Requirements
- **Python 3.8+**
- Works on **Windows, macOS, and Linux**
- No additional libraries needed — just built-in Tkinter.

---

## 🚀 How to Play
1. Run the game:
   ```bash
   python snake_game.py
